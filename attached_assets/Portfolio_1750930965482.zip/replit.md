# Portfolio Application

## Overview

This is a modern portfolio website for Muhammad Zain, a front-end developer. The application is built using Next.js 15 with TypeScript and Framer Motion animations. It features a responsive, minimalist black and white design showcasing professional experience, skills, projects, and includes an interactive contact form with smooth animations throughout.

## System Architecture

### Frontend Architecture
- **Framework**: Next.js 15 with TypeScript and App Router
- **Styling**: Tailwind CSS with custom black and white minimalist design
- **Animations**: Framer Motion for smooth, modern animations throughout
- **Icons**: Lucide React for consistent iconography
- **Typography**: Inter font for professional appearance
- **Responsive**: Mobile-first responsive design with smooth scroll behavior

### Animation Features
- **Hero Section**: Fade-in effects for text, zoom-in animation for profile image
- **About Section**: Slide-in effects when entering viewport, hover effects on social links
- **Skills Section**: Animated progress bars with fill effects, bouncing skill icons
- **Experience**: Timeline elements fade/slide up on scroll
- **Projects**: Hover effects on project cards, reveal animations for descriptions
- **Education**: Zoom effects for individual entries
- **Contact**: Bounce effects for form buttons, smooth form animations

### Build System
- **Development**: Next.js dev server with hot reloading
- **Build**: Next.js optimized production builds
- **Styling**: Tailwind CSS with PostCSS processing

## Key Components

### Frontend Components
1. **Portfolio Sections**:
   - Navigation with smooth scrolling
   - Hero section with personal introduction
   - About section with professional summary
   - Skills section with animated progress bars
   - Experience timeline
   - Projects showcase
   - Education and certifications
   - Contact form with validation

2. **UI System**:
   - Shadcn/ui component library
   - Consistent design tokens via CSS variables
   - Responsive design patterns
   - Accessibility-first approach

### Backend Components
1. **API Routes**:
   - `POST /api/contact` - Contact form submission
   - `GET /api/contact-messages` - Retrieve all messages (admin)

2. **Data Models**:
   - Users table for potential authentication
   - Contact messages table for form submissions

3. **Storage Layer**:
   - Drizzle ORM for type-safe database operations
   - Memory storage fallback for development
   - Schema validation with Zod

## Data Flow

1. **Contact Form Submission**:
   - User fills out contact form in React
   - Form validation using React Hook Form + Zod
   - API request to `/api/contact` endpoint
   - Server validates data and stores in PostgreSQL
   - Success/error feedback via toast notifications

2. **Portfolio Content**:
   - Static content rendered from React components
   - Animations triggered by scroll position
   - Responsive layout adjustments based on viewport

3. **Development Workflow**:
   - Vite dev server for frontend with HMR
   - Express server for API endpoints
   - Concurrent development with live reloading

## External Dependencies

### Frontend Dependencies
- **React Ecosystem**: React 18, React DOM, React Hook Form
- **UI & Styling**: Tailwind CSS, Radix UI components, Framer Motion
- **Utilities**: Clsx, class-variance-authority, date-fns
- **Icons**: Lucide React
- **State Management**: TanStack React Query

### Backend Dependencies
- **Server**: Express.js, Node.js
- **Database**: Drizzle ORM, @neondatabase/serverless
- **Validation**: Zod for schema validation
- **Session**: connect-pg-simple for session storage
- **Development**: tsx for TypeScript execution

### Development Tools
- **Build Tools**: Vite, esbuild
- **TypeScript**: Full type safety across frontend and backend
- **Linting/Formatting**: TypeScript compiler for type checking

## Deployment Strategy

### Production Build
1. **Frontend**: Vite builds optimized React application to `dist/public`
2. **Backend**: esbuild bundles Express server to `dist/index.js`
3. **Database**: Drizzle migrations applied to PostgreSQL instance

### Environment Configuration
- **Development**: Uses Vite dev server with Express backend
- **Production**: Serves static assets from Express with API routes
- **Database**: Neon Database (serverless PostgreSQL) via `DATABASE_URL`

### Replit Configuration
- **Modules**: nodejs-20, web, postgresql-16
- **Deployment**: Autoscale deployment target
- **Port**: Application runs on port 5000, exposed on port 80
- **Build Command**: `npm run build`
- **Start Command**: `npm run start`

## Changelog

Changelog:
- June 24, 2025: Migrated from Express/Vite to Next.js 15 with Framer Motion
- Added comprehensive animations throughout all sections
- Implemented black and white minimalist design theme
- Created responsive portfolio with smooth scrolling navigation
- Added interactive contact form with client-side validation

## User Preferences

Preferred communication style: Simple, everyday language.