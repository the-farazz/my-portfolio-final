const { spawn } = require('child_process');

const child = spawn('npx', ['next', 'dev', '-p', '5000', '-H', '0.0.0.0'], {
  stdio: 'inherit',
  env: { ...process.env, PORT: '5000' }
});

child.on('exit', (code) => {
  process.exit(code);
});
